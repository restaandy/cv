<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Responsive Bootstrap Sility - vCard, CV & Resume HTML Template">
    <meta name="keywords" content=" minimal html cv resume template,signature resume cv portfolio html template">
    <meta name="author" content="Varun Sridharan [TechNoFreaky]"> 
    <meta property="og:title" content="Sility - vCard, CV & Resume HTML Template"/>
    <meta property="og:description" content="Responsive Bootstrap Sility - vCard, CV & Resume HTML Template" />
    <meta property="og:url" content="http://www.example.com" />
    <meta property="og:site_name" content="Sility - vCard"/>
    <meta property="og:image" content="http://example.com/ogp.jpg" />

    <meta name="twitter:card" content="Summary">

    <meta name="twitter:site" content="@SiteName">

    <meta name="twitter:creator" content="@AuthorHandle">

    <meta name="twitter:title" content="Article Title ">

    <meta name="twitter:description" content="Page Description">

    <meta name="twitter:image:src" content="Image URL">

    <title>Template CV | WEB Developer, IT Consultant</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Icons -->
    <link href="<?php echo base_url(); ?>assets/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- Ionicons -->
    <link href="<?php echo base_url(); ?>assets/fonts/ionicons/css/ionicons.min.css" rel="stylesheet">
    <!-- Owl Carousel -->
    <link href="<?php echo base_url(); ?>assets/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/owl.theme.default.css" rel="stylesheet">
    <!-- Style.css -->
    <link rel=" stylesheet" title="deep_purple" type="text/css"  data-color="#673AB7" href="<?php echo base_url(); ?>assets/color/deep_purple.css"  />


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>

    <!-- Search -->
    <div class="search-overlay"></div>
    <div class="search">
        <a href="#" class="search-close"><i class="md md-close"></i></a>
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
                <h4>Just Start Typing Text and Press Enter</h4>
                <form class="search-form">
                    <input type="text" id="search" name="search" class="text-center" />
                </form>
                <!-- end .search-form -->
            </div>
            <!-- end .col-sm-6 -->
        </div>
        <!-- end .row -->
    </div>
    <!-- end .row -->
    <!-- Slide Out -->
    <div class="slide-out-overlay"></div>
    <div class="slide-out">
        <header class="slide-out-header clearfix">
            <div class="clearfix">
                <a href="#" class="slide-out-close pull-left"><i class="md md-close"></i></a>
                <a href="#" class="open-search pull-right"><i class="md md-search"></i></a>
                <a href="#" class="slide-out-share pull-right"><i class="md md-more-vert"></i></a>
            </div>
            <!-- end .clearfix -->
            <!-- Popup -->
            <div class="slide-out-popup">
                <nav class="social-nav">
                    <ul class="list-unstyled">
                        <li><a href="#">Facebook</a>
                        </li>
                        <li><a href="#">Twitter</a>
                        </li>
                        <li><a href="#">Linkedin</a>
                        </li>
                        <li><a href="#">Google+</a>
                        </li>
                        <li><a href="#">Behance</a>
                        </li>
                    </ul>
                    <!-- end .list-unstyled -->
                </nav>
                <!-- end .social-nav -->
            </div>
            <!-- end .slide-out-popup -->
            <div class="image"><img src="<?php echo base_url(); ?>assets/images/head01.png" alt="alt text" class="img-responsive">
            </div>
            <div class="content">
                <h5>Benjamin Thomson</h5>
                <span>Web & UX Designer</span>
            </div>
            <!-- end .content -->
            <div class="text-right">
                <a href="#" class="button link-button white icon-left"><i class="md md-file-download"></i>Download Resume</a>
            </div>
            <!-- end .text-right -->
        </header>
        <!-- end .slide-out-header -->
        <div class="slide-out-widgets">
            <div class="slide-out-widget">
                <h4>Drink A Coffee With Me Today</h4>
                <form action="#" method="post" class="form-horizontal contact-form">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="contact-name" name="contact-name" />
                        </div>
                        <!-- end .col-sm-9 -->
                    </div>
                    <!-- end .form-group -->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-9">
                            <input type="email" class="contact-email" name="contact-email" />
                        </div>
                        <!-- end .col-sm-9 -->
                    </div>
                    <!-- end .form-group -->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Message</label>
                        <div class="col-sm-9">
                            <textarea name="contact-message" class="contact-message" rows="3"></textarea>
                        </div>
                        <!-- end .col-sm-9 -->
                    </div>
                    <!-- end .form-group -->
                    <div class="form-group">
                        <div class="col-sm-9 col-sm-offset-3">
                            <button type="submit" class="button solid-button purple">Send Message</button>
                        </div>
                        <!-- end .col-sm-9 -->
                    </div>
                    <!-- end .form-group -->
                    <div class="contact-loading alert alert-info form-alert">
                        <span class="message">Loading...</span>
                        <button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i>
                        </button>
                    </div>
                    <div class="contact-success alert alert-success form-alert">
                        <span class="message">Success!</span>
                        <button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i>
                        </button>
                    </div>
                    <div class="contact-error alert alert-danger form-alert">
                        <span class="message">Error!</span>
                        <button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i>
                        </button>
                    </div>
                </form>
                <!-- end contact-form -->
            </div>
            <!-- end .slide-out-widget -->
            <div class="slide-out-widget">
                <h4>Follow On Instagram</h4>
                <div class="instagram">
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/instagram01.jpg" alt="alt text" class="img-responsive">
                    </a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/instagram02.jpg" alt="alt text" class="img-responsive">
                    </a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/instagram03.jpg" alt="alt text" class="img-responsive">
                    </a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/instagram04.jpg" alt="alt text" class="img-responsive">
                    </a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/instagram05.jpg" alt="alt text" class="img-responsive">
                    </a>
                    <a href="#"><img src="<?php echo base_url(); ?>assets/images/instagram06.jpg" alt="alt text" class="img-responsive">
                    </a>
                </div>
                <!-- end .instagram -->
            </div>
            <!-- end .slide-out-widget -->
        </div>
        <!-- end .slide-out-widgets -->
    </div>
    <!-- end .slide-out -->

    <!-- Header -->
    <header class="header">
        <div class="top clearfix">
            <a href="#section8" class="available"><i class="ion-ios-email-outline"></i><span>Available For Freelance</span></a>
            <div class="right-icons">
                <a href="#" class="open-search header-open-search"><i class="md md-search"></i></a>
                <a href="#" class="download"><i class="md md-file-download"></i></a>
                <a href="#" class="share"><i class="md md-more-vert"></i></a>
            </div>
            <!-- end .right-icons -->
            <!-- Popup -->
            <div class="popup">
                <nav class="social-nav">
                    <ul class="list-unstyled">
                        <li><a href="#">Facebook</a>
                        </li>
                        <li><a href="#">Twitter</a>
                        </li>
                        <li><a href="#">Linkedin</a>
                        </li>
                        <li><a href="#">Google+</a>
                        </li>
                        <li><a href="#">Behance</a>
                        </li>
                    </ul>
                    <!-- end .list-unstyled -->
                </nav>
                <!-- end .social-nav -->
            </div>
            <!-- end .popup -->
        </div>
        <!-- end .top -->
        <div class="bottom clearfix">
            <div class="title"><a href="index-2.html">Sility</a>
            </div>
            <div class="header-action-button-wrapper">
                <a href="#" class="header-action-button action-button"><i class="md md-add"></i></a>
            </div>
            <!-- end .header-action-button-wrapper -->
            <a href="#" class="responsive-menu-open">Menu <i class="fa fa-bars"></i></a>
            <nav class="main-nav">
                <ul class="list-unstyled">
                    <li class="active"><a href="#section1">Home</a>
                    </li>
                    <li><a href="#section2">About</a>
                    </li>
                    <li><a href="#section3">Skill</a>
                    </li>
                    <li><a href="#section4">Experience</a>
                    </li>
                    <li><a href="#section5">Education</a>
                    </li>
                    <li><a href="#section6">Work</a>
                    </li>
                    <li><a href="#section7">Blog</a>
                    </li>
                    <li><a href="#section8">Contact</a>
                    </li>
                </ul>
            </nav>
            <!-- end .main-nav -->
        </div>
        <!-- end .bottom -->
    </header>
    <!-- end .header -->
    <div class="responsive-menu">
        <a href="#" class="responsive-menu-close">Close <i class="ion-android-close"></i></a>
        <nav class="responsive-nav"></nav>
        <!-- end .responsive-nav -->
    </div>
    <!-- end .responsive-menu -->

    <!-- Section Navigation -->
    <div class="section-nav">
        <nav class="section1">
            <a href="#section2" class="forward"><i class="md md-chevron-right"></i></a>
            <a href="#section1" class="backward"><i class="md md-chevron-left"></i></a>
        </nav>
    </div>
    <!-- end .section-nav -->

    <!-- Sections -->
    <div class="sections">
        <div class="sections-wrapper clearfix">

            <!-- Home -->
            <section id="section1" class="no-padding-bottom active">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-7 vertical-center padding-fix">
                            <h1>Design<sup>+</sup> Develope<sup>+</sup> Interactive<sup>+</sup> Art<sup>+</sup></h1>
                            <p>Hello, I’m Benjamin Thomson. I Have 8 years of experience in Web and UX design. I am worked on a variety of brands and with agencies both big and small.</p>
                            <p class="button-row"><a href="#" class="button solid-button white">Hire Me Now</a><a href="#" class="button solid-button purple">Download CV</a>
                            </p>
                        </div>
                        <!-- end .col-sm-7 -->
                        <div class="col-sm-5 vertical-center">
                            <img src="<?php echo base_url(); ?>assets/images/man01.png" alt="man" class="img-responsive section-img">
                        </div>
                        <!-- end .col-sm-5 -->
                    </div>
                    <!-- end .row -->
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- About -->
            <section id="section2">
                <div class="container">
                    <h2>About Me</h2>
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="<?php echo base_url(); ?>assets/images/man02.png" alt="man" class="img-responsive section-img">
                        </div>
                        <!-- end .col-sm-3 -->
                        <div class="col-sm-9">
                            <h3 class="small-margin-bottom">Benjamin Thomson</h3>
                            <h5>Web & UX Designer</h5>
                            <p>Ultricies nisi voluptatem, illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo nemo enim ipsam voluptatem. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque latu dantium, totam rem aperiam, eaque ipsa quae ab illo tempor dignissim at. </p>
                            <div class="signature"><img src="<?php echo base_url(); ?>assets/images/signature.png" alt="signature" class="img-responsive">
                            </div>
                            <ul class="list-unstyled text-uppercase">
                                <li><b>Date Of Birth:</b> 24 Jan 1989</li>
                                <li><b>Phone:</b> 012-345-6789</li>
                                <li><b>Email:</b> Sility@example.com</li>
                                <li><b>Address:</b> 123 Sility, South Corner Street, Melborne, Australia.</li>
                                <li><b>Website:</b> http://www.example.com</li>
                            </ul>
                            <!-- end .list-unstyled -->
                            <div class="spacer"></div>
                            <h3>What I'm Doing</h3>
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="service">
                                        <div class="icon"><i class="ion-monitor"></i>
                                        </div>
                                        <h5>Web & UX Design</h5>
                                    </div>
                                    <!-- end .service -->
                                </div>
                                <!-- end .col-sm-4 -->
                                <div class="col-sm-4">
                                    <div class="service">
                                        <div class="icon"><i class="ion-iphone"></i>
                                        </div>
                                        <h5>App Development</h5>
                                    </div>
                                    <!-- end .service -->
                                </div>
                                <!-- end .col-sm-4 -->
                                <div class="col-sm-4">
                                    <div class="service">
                                        <div class="icon"><i class="ion-trophy"></i>
                                        </div>
                                        <h5>Marketing</h5>
                                    </div>
                                    <!-- end .service -->
                                </div>
                                <!-- end .col-sm-4 -->
                            </div>
                            <!-- end .row -->
                        </div>
                        <!-- end .col-sm-9 -->
                    </div>
                    <!-- end .row -->
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- Skills -->
            <section id="section3">
                <div class="container">
                    <h2>My Skills Values</h2>
                    <div class="row">
                        <div class="col-sm-6">
                            <h4>Technical Skills</h4>
                            <label class="progress-bar-label">Wordpress</label>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">
                                    <span>85%</span>
                                </div>
                                <!-- end .progress-bar -->
                            </div>
                            <!-- end .progress -->
                            <label class="progress-bar-label">Photoshop</label>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="99" aria-valuemin="0" aria-valuemax="100">
                                    <span>99%</span>
                                </div>
                                <!-- end .progress-bar -->
                            </div>
                            <!-- end .progress -->
                            <label class="progress-bar-label">HTML&amp;CSS</label>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                                    <span>75%</span>
                                </div>
                                <!-- end .progress-bar -->
                            </div>
                            <!-- end .progress -->
                            <label class="progress-bar-label">Javascript</label>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100">
                                    <span>67%</span>
                                </div>
                                <!-- end .progress-bar -->
                            </div>
                            <!-- end .progress -->
                        </div>
                        <!-- end .col-sm-6 -->
                        <div class="col-sm-6">
                            <h4>Knowledge</h4>
                            <div class="row">
                                <div class="col-sm-6">
                                    <ul class="list-icons purple bold-list">
                                        <li><i class="md-arrow-forward"></i>Install and Configure</li>
                                        <li><i class="md-arrow-forward"></i>Web Usability</li>
                                        <li><i class="md-arrow-forward"></i>Digital Painting</li>
                                        <li><i class="md-arrow-forward"></i>Grid and Layout</li>
                                        <li><i class="md-arrow-forward"></i>Mobile App Design</li>
                                        <li><i class="md-arrow-forward"></i>Graphical Design</li>
                                        <li><i class="md-arrow-forward"></i>SEO Optimization</li>
                                    </ul>
                                </div>
                                <!-- end .col-sm-6 -->
                                <div class="col-sm-6">
                                    <ul class="list-icons purple bold-list">
                                        <li><i class="md-arrow-forward"></i>UX and UI Design</li>
                                        <li><i class="md-arrow-forward"></i>Logo Design</li>
                                        <li><i class="md-arrow-forward"></i>3D Animation & Visual Effects</li>
                                        <li><i class="md-arrow-forward"></i>Audio Video Editing</li>
                                        <li><i class="md-arrow-forward"></i>Photography</li>
                                        <li><i class="md-arrow-forward"></i>Web Development</li>
                                        <li><i class="md-arrow-forward"></i>Digital Marketing</li>
                                    </ul>
                                </div>
                                <!-- end .col-sm-6 -->
                            </div>
                            <!-- end .row -->
                        </div>
                        <!-- end .col-sm-6 -->
                    </div>
                    <!-- end .row -->
                    <div class="spacer"></div>
                    <h4>Language Skills</h4>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="circle-progress-wrapper clearfix">
                                <div class="circle-progress">
                                    <input type="text" class="dial" value="99" data-color="#7c4dff" data-from="0" data-to="99" />
                                </div>
                                <!-- end .circle-progress -->
                                <div class="circle-progress-label-wrapper">
                                    <label class="circle-progress-label">English Experienced</label>
                                </div>
                            </div>
                            <!-- end .circle-progress-wrapper -->
                        </div>
                        <!-- end .col-sm-4 -->
                        <div class="col-sm-4">
                            <div class="circle-progress-wrapper clearfix">
                                <div class="circle-progress">
                                    <input type="text" class="dial" value="80" data-color="#7c4dff" data-from="0" data-to="80" />
                                </div>
                                <!-- end .circle-progress -->
                                <div class="circle-progress-label-wrapper">
                                    <label class="circle-progress-label">French Advanced</label>
                                </div>
                            </div>
                            <!-- end .circle-progress-wrapper -->
                        </div>
                        <!-- end .col-sm-4 -->
                        <div class="col-sm-4">
                            <div class="circle-progress-wrapper clearfix">
                                <div class="circle-progress">
                                    <input type="text" class="dial" value="69" data-color="#7c4dff" data-from="0" data-to="69" />
                                </div>
                                <!-- end .circle-progress -->
                                <div class="circle-progress-label-wrapper">
                                    <label class="circle-progress-label">German Basic</label>
                                </div>
                            </div>
                            <!-- end .circle-progress-wrapper -->
                        </div>
                        <!-- end .col-sm-4 -->
                    </div>
                    <!-- end .row -->
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- Experience -->
            <section id="section4">
                <div class="container">
                    <h2>8 Years Experience</h2>
                    <div class="experience-timeline">
                        <div class="experience-block clearfix">
                            <div class="meta">
                                <span class="year">2012 - Current</span>
                                <span class="company">Themeforest</span>
                            </div>
                            <!-- end .meta -->
                            <div class="content">
                                <h5>Senior Web & UX Designer</h5>
                                <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velitus sed quia non num quam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                            </div>
                            <!-- end .content -->
                            <div class="icon">
                                <i class="ion-easel"></i>
                            </div>
                            <!-- end .icon -->
                            <div class="line"></div>
                        </div>
                        <!-- end .experience-block -->
                        <div class="experience-block clearfix">
                            <div class="meta">
                                <span class="year">2008 - 2012</span>
                                <span class="company">Graphicriver</span>
                            </div>
                            <!-- end .meta -->
                            <div class="content">
                                <h5>Graphic Designer</h5>
                                <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velitus sed quia non num quam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                            </div>
                            <!-- end .content -->
                            <div class="icon">
                                <i class="ion-images"></i>
                            </div>
                            <!-- end .icon -->
                            <div class="line"></div>
                        </div>
                        <!-- end .experience-block -->
                        <div class="experience-block clearfix">
                            <div class="meta">
                                <span class="year">2006 - 2008</span>
                                <span class="company">Codecanyon</span>
                            </div>
                            <!-- end .meta -->
                            <div class="content">
                                <h5>Web Developer</h5>
                                <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velitus sed quia non num quam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                            </div>
                            <!-- end .content -->
                            <div class="icon">
                                <i class="ion-card"></i>
                            </div>
                            <!-- end .icon -->
                        </div>
                        <!-- end .experience-block -->
                    </div>
                    <!-- end .experience-timeline -->

                    <!-- Testimonials -->
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2">
                            <div class="testimonial-slider owl-carousel">
                                <div>
                                    <div class="image"><img src="<?php echo base_url(); ?>assets/images/testimonial.jpg" alt="alt text">
                                    </div>
                                    <div class="sep"></div>
                                    <p>" Awesome to work with. Incredibly organized, easy to communicate with, responsive with next iterations, and beautiful work. "</p>
                                    <span class="author">swetain , CEO of Texco Company</span>
                                </div>
                                <div>
                                    <div class="image"><img src="<?php echo base_url(); ?>assets/images/testimonial.jpg" alt="alt text">
                                    </div>
                                    <div class="sep"></div>
                                    <p>" Awesome to work with. Incredibly organized, easy to communicate with, responsive with next iterations, and beautiful work. "</p>
                                    <span class="author">swetain , CEO of Texco Company</span>
                                </div>
                                <div>
                                    <div class="image"><img src="<?php echo base_url(); ?>assets/images/testimonial.jpg" alt="alt text">
                                    </div>
                                    <div class="sep"></div>
                                    <p>" Awesome to work with. Incredibly organized, easy to communicate with, responsive with next iterations, and beautiful work. "</p>
                                    <span class="author">swetain , CEO of Texco Company</span>
                                </div>
                            </div>
                            <!-- end .testimonial-slider -->
                        </div>
                        <!-- end .col-sm-8 -->
                    </div>
                    <!-- end .row -->

                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- Education -->
            <section id="section5">
                <div class="container">
                    <h2>Educational Value</h2>
                    <div class="education clearfix">
                        <div class="item">
                            <div class="marker"></div>
                            <div class="content">
                                <span>University Of Design</span>
                                <h4>Master Degree of Design</h4>
                            </div>
                            <div class="year">2005 - 2006</div>
                        </div>
                        <!-- end item -->
                        <div class="item">
                            <div class="marker"></div>
                            <div class="content">
                                <span>University Of Design</span>
                                <h4>Master Degree of Design</h4>
                            </div>
                            <div class="year">2005 - 2006</div>
                        </div>
                        <!-- end item -->
                        <div class="item">
                            <div class="marker"></div>
                            <div class="content">
                                <span>University Of Design</span>
                                <h4>Master Degree of Design</h4>
                            </div>
                            <div class="year">2005 - 2006</div>
                        </div>
                        <!-- end item -->
                        <div class="item">
                            <div class="marker"></div>
                            <div class="content">
                                <span>University Of Design</span>
                                <h4>Master Degree of Design</h4>
                            </div>
                            <div class="year">2005 - 2006</div>
                        </div>
                        <!-- end item -->
                        <div class="line"></div>
                    </div>
                    <!-- end .education -->

                    <h2>Hobbies & Interest</h2>
                    <div class="row">
                        <div class="col-sm-2 col-sm-offset-1 col-xs-6">
                            <div class="icon-box">
                                <div class="icon"><i class="ion-easel"></i>
                                </div>
                                <h6>Web Research</h6>
                            </div>
                            <!-- end .icon-box -->
                        </div>
                        <!-- end .col-sm-2 -->
                        <div class="col-sm-2 col-xs-6">
                            <div class="icon-box">
                                <div class="icon"><i class="ion-ios-camera-outline"></i>
                                </div>
                                <h6>Photography</h6>
                            </div>
                            <!-- end .icon-box -->
                        </div>
                        <!-- end .col-sm-2 -->
                        <div class="col-sm-2 col-xs-6">
                            <div class="icon-box">
                                <div class="icon"><i class="ion-plane"></i>
                                </div>
                                <h6>Travelling</h6>
                            </div>
                            <!-- end .icon-box -->
                        </div>
                        <!-- end .col-sm-2 -->
                        <div class="col-sm-2 col-xs-6">
                            <div class="icon-box">
                                <div class="icon"><i class="ion-ios-bookmarks-outline"></i>
                                </div>
                                <h6>Book Reading</h6>
                            </div>
                            <!-- end .icon-box -->
                        </div>
                        <!-- end .col-sm-2 -->
                        <div class="col-sm-2 col-xs-6">
                            <div class="icon-box">
                                <div class="icon"><i class="ion-ios-musical-notes"></i>
                                </div>
                                <h6>Music</h6>
                            </div>
                            <!-- end .icon-box -->
                        </div>
                        <!-- end .col-sm-2 -->
                    </div>
                    <!-- end .row -->
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- Portfolio -->
            <section id="section6">
                <div class="container">
                    <h2>Portfolio</h2>
                    <div class="portfolio-wrapper">
                        <div id="portfolio-filters" class="portfolio-filters">
                            <button class="button solid-button white-purple small" data-filter="*">Show All</button>
                            <button class="button solid-button white-purple small" data-filter=".branding">Branding</button>
                            <button class="button solid-button white-purple small" data-filter=".print">Print</button>
                            <button class="button solid-button white-purple small" data-filter=".motion">Motion</button>
                            <button class="button solid-button white-purple small" data-filter=".websites">Websites</button>
                        </div>
                        <div id="portfolio" class="portfolio">
                            <div class="item branding print">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio01.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 01</span>
                                        <span class="category">Branding, Print</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item motion">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio02.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 02</span>
                                        <span class="category">Motion</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item print">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio03.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 03</span>
                                        <span class="category">Print</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item print branding websites">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio04.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 04</span>
                                        <span class="category">Branding, Websites</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item print branding">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio05.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 05</span>
                                        <span class="category">Print, Branding</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item motion">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio06.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 06</span>
                                        <span class="category">Motion</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item motion">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio07.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 07</span>
                                        <span class="category">Motion</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item print">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio08.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 08</span>
                                        <span class="category">Print</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item motion">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio09.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 09</span>
                                        <span class="category">Motion</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                            <div class="item websites">
                                <img src="<?php echo base_url(); ?>assets/images/portfolio10.jpg" alt="alt text" class="img-responsive">
                                <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="overlay">
                                    <div class="background"></div>
                                    <div class="meta">
                                        <span class="title">Portfolio Item - 10</span>
                                        <span class="category">Websites</span>
                                    </div>
                                    <!-- end .meta -->
                                </a>
                                <!-- end .overlay -->
                            </div>
                            <!-- end .item -->
                        </div>
                        <!-- end .portfolio -->
                        <div class="portfolio-load-more">
                            <a href="<?php echo base_url(); ?>assets/single-portfolio.html" class="button solid-button white icon-right">Load More Work<i class="md-refresh"></i></a>
                        </div>
                        <!-- end .portfolio-load-more -->
                    </div>
                    <!-- end .portfolio-wrapper -->
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- Blog -->
            <section id="section7">
                <div class="container">
                    <h2>Blog Post</h2>
                    <div class="blog-posts masonry" id="blog-masonry">
                        <div class="blog-grid-sizer"></div>
                        <div class="blog-post image-left">
                            <div class="inner">
                                <a href="<?php echo base_url(); ?>assets/single-blog-post.html">
                                    <div class="image" style="background-image: url('<?php echo base_url(); ?>assets/images/blog-post-image01.jpg');"></div>
                                </a>
                                <div class="content">
                                    <span class="date">March 14, 2015</span>
                                    <h4><a href="single-blog-post.html">We Support Any Type Of Design</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">3 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                        <div class="blog-post">
                            <div class="inner">
                                <div class="content">
                                    <span class="date">March 15, 2015</span>
                                    <h4><a href="single-blog-post.html">We Give 99% Satisfy In All Work</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">7 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                        <div class="blog-post image-top">
                            <div class="inner">
                                <a href="single-blog-post.html">
                                    <div class="image" style="background-image: url('<?php echo base_url(); ?>assets/images/blog-post-image02.jpg');"></div>
                                </a>
                                <div class="content">
                                    <span class="date">March 13, 2015</span>
                                    <h4><a href="single-blog-post.html">We Won CSS Design Of The Year</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">4 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                        <div class="blog-post image-top">
                            <div class="inner">
                                <a href="single-blog-post.html">
                                    <div class="image" style="background-image: url('<?php echo base_url(); ?>assets/images/blog-post-image03.jpg');"></div>
                                </a>
                                <div class="content">
                                    <span class="date">March 12, 2015</span>
                                    <h4><a href="single-blog-post.html">How to Launch Website Easily</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">10 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                        <div class="blog-post image-right">
                            <div class="inner">
                                <a href="single-blog-post.html">
                                    <div class="image" style="background-image: url('<?php echo base_url(); ?>assets/images/blog-post-image04.jpg');"></div>
                                </a>
                                <div class="content">
                                    <span class="date">March 11, 2015</span>
                                    <h4><a href="single-blog-post.html">Music Is Help To Relax Body And Mind</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">5 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                        <div class="blog-post">
                            <div class="inner">
                                <div class="content">
                                    <span class="date">March 10, 2015</span>
                                    <h4><a href="single-blog-post.html">We Support any Type of Design</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">3 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                        <div class="blog-post image-left">
                            <div class="inner">
                                <a href="single-blog-post.html">
                                    <div class="image" style="background-image: url('<?php echo base_url(); ?>assets/images/blog-post-image05.jpg');"></div>
                                </a>
                                <div class="content">
                                    <span class="date">March 9, 2015</span>
                                    <h4><a href="single-blog-post.html">Change Your Domain Without Risk</a></h4>
                                    <footer>
                                        <span class="comments-link"><a href="single-blog-post.html">6 Comments</a></span>
                                        <span class="share-link"><a href="single-blog-post.html"><i class="fa fa-share-alt"></i></a></span>
                                    </footer>
                                </div>
                                <!-- end .content -->
                            </div>
                            <!-- end .inner -->
                        </div>
                        <!-- end .blog-post -->
                    </div>
                    <!-- end .blog-posts -->
                    <div class="blog-load-more">
                        <a href="single-blog-post.html" class="button solid-button white icon-right">Load More Posts<i class="md-refresh"></i></a>
                    </div>
                    <!-- end .blog-load-more -->
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

            <!-- Contact -->
            <section id="section8">
                <div class="container">
                    <h2>Get In Touch With Me</h2>
                    <div class="row">
                        <div class="col-sm-5">
                            <h5>Contact Address</h5>
                            <ul class="list-icons list-unstyled">
                                <li><i class="ion-ios-location-outline"></i>123 Sility, South Corner Street,
                                    <br />Melbornem Australia.</li>
                                <li><i class="ion-iphone"></i>Phone: +61 012 345 6789</li>
                                <li><i class="ion-ios-email-outline"></i>Email: <a href="mailto:example@gmail.com">example@gmail.com</a>
                                </li>
                                <li><i class="ion-ios-home-outline"></i>Website: <a href="#">info@sility.com</a>
                                </li>
                            </ul>
                            <div class="spacer"></div>
                            <div class="social-icons">
                                <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-google-plus"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-behance"></i></a>
                                <a href="#" class="social-icon"><i class="fa fa-dribbble"></i></a>
                            </div>
                            <!-- end .social-icons -->
                            <div class="spacer"></div>
                        </div>
                        <div class="col-sm-7">
                            <h5>Contact Form</h5>
                            <form action="#" method="post" class="form-horizontal contact-form">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="contact-name" name="contact-name" />
                                    </div>
                                    <!-- end .col-sm-10 -->
                                </div>
                                <!-- end .form-group -->
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="contact-email" name="contact-email" />
                                    </div>
                                    <!-- end .col-sm-10 -->
                                </div>
                                <!-- end .form-group -->
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Message</label>
                                    <div class="col-sm-10">
                                        <textarea name="contact-message" class="contact-message" rows="3"></textarea>
                                    </div>
                                    <!-- end .col-sm-10 -->
                                </div>
                                <!-- end .form-group -->
                                <div class="form-group">
                                    <div class="col-sm-10 col-sm-offset-2">
                                        <button type="submit" class="button solid-button purple">Send Message</button>
                                    </div>
                                    <!-- end .col-sm-10 -->
                                </div>
                                <!-- end .form-group -->
                                <div class="contact-loading alert alert-info form-alert">
                                    <span class="message">Loading...</span>
                                    <button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i>
                                    </button>
                                </div>
                                <div class="contact-success alert alert-success form-alert">
                                    <span class="message">Success!</span>
                                    <button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i>
                                    </button>
                                </div>
                                <div class="contact-error alert alert-danger form-alert">
                                    <span class="message">Error!</span>
                                    <button type="button" class="close" data-hide="alert" aria-label="Close"><i class="fa fa-times"></i>
                                    </button>
                                </div>
                            </form>
                            <!-- end contact-form -->
                        </div>
                    </div>
                    <div class="map" id="map"></div>
                </div>
                <!-- end .container -->
            </section>
            <!-- end #section1 -->

        </div>
        <!-- end .sections-wrapper -->
    </div>
    <!-- end .sections -->

    <!-- Footer -->
    <footer class="footer">
        <div class="top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <h4>Address</h4>
                        <p>123 Sility, South Corner Street,
                            <br />Melbornem Australia.</p>
                    </div>
                    <!-- end .col-sm-4 -->
                    <div class="col-sm-4">
                        <h4>Connect</h4>
                        <div class="social-icons">
                            <a href="#" class="social-icon"><i class="fa fa-facebook"></i></a>
                            <a href="#" class="social-icon"><i class="fa fa-twitter"></i></a>
                            <a href="#" class="social-icon"><i class="fa fa-google-plus"></i></a>
                            <a href="#" class="social-icon"><i class="fa fa-behance"></i></a>
                            <a href="#" class="social-icon"><i class="fa fa-dribbble"></i></a>
                        </div>
                        <!-- end .social-icons -->
                    </div>
                    <!-- end .col-sm-4 -->
                    <div class="col-sm-4">
                        <h4>Contact</h4>
                        <p>Tel: +61 123-456-7890
                            <br />Mail: Sility@example.com</p>
                    </div>
                    <!-- end .col-sm-4 -->
                </div>
                <!-- end .row -->
            </div>
            <!-- end .container -->
        </div>
        <!-- end .footer -->
        <div class="bottom">Copyright &copy; Sility. All Rights Reserved.</div>
        <!-- end .bottom -->
    </footer>
    <!-- end .footer -->

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.11.2.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <!-- Inview -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.inview.min.js"></script>
    <!-- SmoothScroll -->
    <script src="<?php echo base_url(); ?>assets/js/smoothscroll.js"></script>
    <!-- jQuery Knob -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.knob.min.js"></script>
    <!-- Owl Carousel -->
    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
    <!-- Isotope -->
    <script src="<?php echo base_url(); ?>assets/js/isotope.pkgd.min.js"></script>
    <!-- Images Loaded -->
    <script src="<?php echo base_url(); ?>assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- google maps -->
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
    <!-- Scripts.js -->
    <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
   

</body>

</html>